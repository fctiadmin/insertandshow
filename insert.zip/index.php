<?php 
require_once 'db.php';
if(isset($_POST['register'])){
    $firstName=$_POST['firstName'];
    $lastName=$_POST['lastName'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $password=$_POST['password'];
    $confirmPassword=$_POST['confirmPassword'];
    $query=mysqli_query($con,"INSERT INTO `registration`(`first_name`, `last_name`, `email`, `mobile`, `password`) VALUES ('$firstName','$lastName','$email','$phone','$password')");
    if($query){
        echo "<script>
            alert('Successfully Registered');
        </script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Registration Form</title>

   <link rel="stylesheet" href="style.css">
</head>

<body>

    <div class="register-container">

        <div class="form-header">
            <h1>Create Account</h1>
            <p>Register your account to get started</p>
        </div>

        <form  method="POST" class="register-form">

            <div class="row">

                <div class="form-group">
                    <label for="firstName">First Name</label>
                    <input name="firstName" type="text" id="firstName"
                           placeholder="Enter first name"
                           required>
                </div>

                <div class="form-group">
                    <label for="lastName">Last Name</label>
                    <input name="lastName" type="text" id="lastName"
                           placeholder="Enter last name"
                           required>
                </div>

            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <input name="email" type="email" id="email"
                       placeholder="example@email.com"
                       required>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input name="phone" type="tel" id="phone"
                       placeholder="01XXXXXXXXX"
                       required>
            </div>
            <div class="row">

                <div class="form-group">
                    <label for="password">Password</label>
                    <input name="password" type="password" id="password"
                           placeholder="Create password"
                           required>
                </div>

                <div class="form-group">
                    <label for="confirmPassword">Confirm Password</label>
                    <input name="confirmPassword" type="password" id="confirmPassword"
                           placeholder="Confirm password"
                           required>
                </div>

            </div>

            <div class="terms">
                <input name="terms" type="checkbox" id="terms" required>

                <label for="terms">
                    I agree to the
                    <a href="#">Terms & Conditions</a>
                </label>
            </div>

            <button type="submit" name="register" class="register-btn">
                Create Account
            </button>

        </form>

        <div class="login-text">
            Already have an account?
            <a href="#">Login</a>
        </div>

    </div>

</body>
</html>