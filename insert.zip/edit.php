<?php 

$getid=$_GET['getid'];
echo $getid;



?>