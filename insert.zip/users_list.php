<?php 
require_once 'db.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap5.min.css">
</head>
<body>
    <div class="container">


    <table id="example" class="table table-striped">
		<thead>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Phone</th>
				<th>Action</th>
			
			</tr>
		</thead>
		<tbody>
			<?php 
            $select_data=mysqli_query($con,"SELECT * FROM `registration`");
            while($rows=mysqli_fetch_assoc($select_data)){?>
            <tr>
               <td><?php echo $rows['id']?></td>
               <td><?php echo $rows['first_name'].' '.$rows['last_name']?></td>
               <td><?php echo $rows['email']?></td>
               <td><?php echo $rows['mobile']?></td> 
               <td><a href="edit.php?getid=<?php echo $rows['id']?>">Edit</a> | <a href="">Delete</a></td> 
               
            </tr>

<?php
            }
          ?>
		</tbody>

	</table>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/dataTables.bootstrap5.min.js"></script>
    <script src="js/dataTables.min.js"></script>
    <script>

        new DataTable('#example');
    </script>
</body>
</html>